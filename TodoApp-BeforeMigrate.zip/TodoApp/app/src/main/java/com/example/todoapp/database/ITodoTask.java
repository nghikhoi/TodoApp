package com.example.todoapp.database;

public class ITodoTask {
}
